<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class KelasApiController extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        date_default_timezone_set("Asia/Jakarta"); 
        $this->dateToday = date("Y-m-d");
        $this->timeToday = date("h:i:s");
        $this->load->model("GeneralApiModel");
    }

    function gabungKelas_post(){
        $random = random_string('alnum', 6);
        $data = array(
            'kode_referal' => $random,
            'role' => 0,
            'status_pembina' => 0,
            'id_user' => $this->input->post('id_user'),
            'id_kelas' => $this->input->post('id_kelas'),
            'id_pelatihan' => $this->input->post('id_pelatihan'),
            'tgl_join' => $this->dateToday,
            'statusdata' => 0
        );

        $exist_check = array(
            'id' => $data['id_kelas'],
            'status_kelas !=' => 1
        );

        $exist = $this->GeneralApiModel->isDataTransactionalExist($exist_check, "transactional_kelas");

        if(!$exist){
            $exist_check = array(
                'id_user' => $data['id_user'],
                'id_kelas' => $data['id_kelas']
            );
    
            $exist = $this->GeneralApiModel->isDataTransactionalExist($exist_check, "transactional_kode_referal");
    
            if(!$exist){
                $insert = $this->GeneralApiModel->insertTransactional($data, "transactional_kode_referal");
                $this->response(array('status' => 200, 'message' => 'Gabung Kelas Berhasil!', 'data' => $insert));
            }
            else{
                $this->response(array('status' => 200, 'message' => 'Anda telah bergabung pada kelas ini!', 'data' => false));
            }
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Kelas belum dibuka atau sedang berlangsung!', 'data' => false));
        }
    }

    function keluarKelas_post(){
        $data = array(
            'id_user' => $this->input->post('id_user'),
            'id_kelas' => $this->input->post('id_kelas')
        );

        $exist_check = array(
            'id' => $data['id_kelas'],
            'status_kelas >' => 1 //0 = belum dibuka, 1 = pendaftaran, 2 = berjalan, 3 = selesai
        );
        $exist = $this->GeneralApiModel->isDataTransactionalExist($exist_check, "transactional_kelas");
        if(!$exist){
            $delete = $this->GeneralApiModel->deleteTransactional($data, "transactional_kode_referal");
            $this->response(array('status' => 200, 'message' => 'Anda berhasil keluar dari kelas!', 'data' => $delete));
        }else{
            $this->response(array('status' => 200, 'message' => 'Tidak dapat keluar kelas! Kelas sedang berlangsung atau telah selesai', 'data' => false));
        }
    }

    function cariKelas_post(){
        $data = array(
            'kode_referal' => $this->input->post('kode_referal')
        );
        if(!empty($data)){
            $result = $this->GeneralApiModel->getWhereTransactional($data, "kelas_detail")->row();
            if(!empty($result)){
                $this->response(array('status' => 200, 'message' => 'Pencarian Kelas Berhasil!', 'data' => $result));
            }else{
                $this->response(array('status' => 200, 'message' => 'kelas dengan kode referal '.$data['kode_referal'].' tidak ditemukan!', 'data' => null));
            }
            
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Kode Referal kosong! data tidak ditemukan', 'data' => null));
        }
    }

    function masukkanKelas_post(){
        $random = random_string('alnum', 6);
        $data = array(
            'nama' => $this->input->post('nama'),
            'kapasitas' => $this->input->post('kapasitas'),
            'status_kelas' => 0,
            'tgl_buka' => $this->input->post('tgl_buka'),
            'tgl_selesai' => $this->input->post('tgl_selesai'),
            'id_pelatihan' => $this->input->post('id_pelatihan'),
            'kode_referal' => $random
        );
        $exist_check = array(
            'nama' => $data['nama'],
            'id_pelatihan' => $data['id_pelatihan']
        );
        $nama_exist = $this->GeneralApiModel->isDataTransactionalExist($exist_check, "transactional_kelas");
        if($nama_exist){
            $this->response(array('status' => 200, 'message' => 'Nama Kelas sudah tersedia!', 'data' => null));
        }
        else{
            $insert = $this->GeneralApiModel->insertTransactional($data, "transactional_kelas");
            $this->response(array('status' => 200, 'message' => 'Input  kelas sukses!', 'data' => $insert));
        }
    }
    
    function submitPresensi_post(){
        $data = array(
            'id_pelatihan' => $this->input->post('id_pelatihan'),
            'id_user' => $this->input->post('id_user'),
            'id_kelas' => $this->input->post('id_kelas')
        );
        if($data['id_pelatihan'] && $data['id_user'] && $data['id_kelas']){
            $insert = $this->GeneralApiModel->insertTransactional($data, "transactional_presensi");
            $this->response(array('status' => 200, 'message' => 'Input presensi sukses!', 'data' => $insert));
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Form presensi tidak lengkap! submit presensi gagal', 'data' => null));
        }
    }
    
    function submitTopikSelesai_post(){
        $data = array(
            'id_materi' => $this->input->post('id_materi'),
            'id_subbab_materi' => $this->input->post('id_subbab_materi'), 
            'id_user' => $this->input->post('id_user')
        );
        if($data['id_materi'] && $data['id_subbab_materi'] && $data['id_user']){
            $insert = $this->GeneralApiModel->insertTransactional($data, "transactional_progress_materi");
            $this->response(array('status' => 200, 'message' => 'Input progress materi sukses!', 'data' => $insert));
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Form input progress tidak lengkap! submit progress materi gagal', 'data' => null));
        }
    }
    
    function dataKodeReferal_post(){
        $data = array(
            'id_pelatihan' => $this->input->post('id_pelatihan'),
            'id_user' => $this->input->post('id_user'),
            'id_kelas' => $this->input->post('id_kelas')
        );
        if($data['id_pelatihan'] && $data['id_user'] && $data['id_kelas']){
            $result = $this->GeneralApiModel->getWhereTransactional($data, "transactional_kode_referal")->row();
            $this->response(array('status' => 200, 'message' => 'Kode referal berhasil didapatkan', 'data' => $result->kode_referal));
        }
        else{
            $this->response(array('status' => 200, 'message' => 'id yang diperlukan tidak lengkap! data gagal ditampilkan', 'data' => null));
        }
    }
    
    function perbaruiReferal_post(){
        $kode_referal = random_string('alnum', 6);
        
        $id_user = $this->input->post('id_user');
        $where = array(
            'id_user' => $id_user,
            'id_pelatihan' => $this->input->post('id_pelatihan'),
            'id_kelas' => $this->input->post('id_kelas')
        );

        $data = array(
            'kode_referal' => $kode_referal
        );

        $result = $this->GeneralApiModel->updateTransactional($data,$where,"transactional_kode_referal");

        if($result){
            $this->response(array('status' => 200, 'message' => 'Kode Referal Berhasil Diperbarui', 'data' => $data['kode_referal']));
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Peserta tidak ditemukan! Kode Referal Gagal Diperbarui', 'data' => null));
        }
    }
    
    function dataTest_post(){
        $where = array(
            'id_subbab_materi' => $this->input->post('id_subbab_materi')
        );
        if($where['id_subbab_materi']){
            $data = array(
                'id_subbab_materi' => $where['id_subbab_materi'],
                'data_soal' => array()
            );
            $result = $this->GeneralApiModel->getWhereMaster($where, "masterdata_test")->result();
            $i = 0;
            if(!empty($result)){
                foreach($result as $row){
                    $data['data_soal'][$i]['id_soal'] = $row->id_soal;
                    $data['data_soal'][$i]['soal'] = $row->soal;
                    $data['data_soal'][$i]['tipe'] = $row->tipe;
                    $data['data_soal'][$i]['id_subbab_materi'] = $row->id_subbab_materi;
                    $data['data_soal'][$i]['data_jawaban'] = array();
                    
                    $where2 = array(
                        'id_test' => $row->id_soal
                    );
                    
                    $result2 = $this->GeneralApiModel->getWhereMaster($where2, "masterdata_pilihan_jawaban_test")->result();
                    $j = 0;
                    foreach($result2 as $row){
                        $data['data_soal'][$i]['data_jawaban'][$j]['id'] = $row->id;
                        $data['data_soal'][$i]['data_jawaban'][$j]['jawaban'] = $row->jawaban;
                        $data['data_soal'][$i]['data_jawaban'][$j]['is_benar'] = $row->is_benar;
                        
                        $j++;
                    }
                    
                    $i++;
                }
                $this->response(array('status' => 200, 'message' => 'Data test berhasil didapatkan!', 'data' => $data));
            }else{
                $this->response(array('status' => 200, 'message' => 'Subbab materi tidak ditemukan!', 'data' => $null));
            }
        }else{
             $this->response(array('status' => 200, 'message' => 'Masukkan id subbab materi terlebih dahulu! data tidak ditemukan', 'data' => null));
        }
    }
}