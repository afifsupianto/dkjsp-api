<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class KeluargaBinaanApiController extends REST_Controller
{

    function __construct($config = 'rest')
    {
        parent::__construct($config);
        date_default_timezone_set("Asia/Jakarta");
        $this->dateToday = date("Y-m-d H:i:s");
        $this->timeToday = date("h:i:s");
        $this->load->model("GeneralApiModel");
        $this->load->model("KeluargaBinaanApiModel");
    }

    function getDataKeluargaBinaan_post(){
        $where = array(
            'nomor_kk' => $this->input->post('nomor_kk')
        );
        $result = $this->GeneralApiModel->getWhereTransactional($where, 'keluargabinaan_detail')->result();
        if(!empty($result)){
            $this->response(array('status' => 200, 'message' => 'Data Berhasil Ditemukan!', 'data' => $result[0]));
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Data Keluarga Binaan Tidak Ditemukan!', 'data' => null));
        }
    }

    function updateKeluargaBinaanByPeserta_post(){
        $data = array(
            'status_acc' => $this->input->post('status_acc'), //0 = ..., 1 = ...
            'id_pembina' => $this->input->post('id_pembina')
        );
        $nomor_kk = array(
            'nomor_kk' => $this->input->post('nomor_kk')
        );
        if(($data['status_acc'] == 1) && $data['status_acc'] != ''){
            if(!empty($data['id_pembina'])){
                $result = $this->KeluargaBinaanApiModel->updateKeluargaBinaan($data, $nomor_kk);
                if($result){
                    $this->response(array('status' => 200, 'message' => 'ACC Keluarga Binaan oleh Relawan telah Berhasil!', 'data' => $result));
                }
                else{
                    $this->response(array('status' => 200, 'message' => 'ACC Keluarga Binaan Gagal Dilakukan!', 'data' => null));
                }
            }
            else{
                $this->response(array('status' => 200, 'message' => 'Id Peserta tidak ditemukan! Update Gagal Dilakukan!', 'data' => null));
            }
            
        }else if(($data['status_acc'] == 0) && $data['status_acc'] != ''){
            $data['id_pembina'] = 0;
            $result = $this->KeluargaBinaanApiModel->updateKeluargaBinaan($data, $nomor_kk);
            if($result){
                $this->response(array('status' => 200, 'message' => 'Keluarga Binaan oleh Relawan Berhasil ditolak!', 'data' => $result));
            }
            else{
                $this->response(array('status' => 200, 'message' => 'ACC Keluarga Binaan Gagal Dilakukan!', 'data' => null));
            }
        }
        else{
            $this->response(array('status' => 200, 'message' => 'Status ACC Relawan tidak ditemukan! Update Gagal Dilakukan!', 'data' => null));
        }
        
    }
}