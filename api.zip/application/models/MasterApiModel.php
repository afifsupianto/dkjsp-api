<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MasterApiModel extends CI_Model {
    function __construct(){
        parent::__construct();
    }

    function getViewSemuaKelas(){
        $db = $this->load->database('dkjps_masterdata', TRUE);
        $query = $db->get('semuakelas');
        return $query;
    }
}