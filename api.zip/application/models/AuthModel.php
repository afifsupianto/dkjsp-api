<?php

class AuthModel extends CI_Model{

    function getUser($data){
        $query = $this->db->get_where('user', $data);
        return $query;
    }

}