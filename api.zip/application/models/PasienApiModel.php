<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PasienApiModel extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    //----------------- FUNGSI UNTUK PUSKESMAS ------------------------------
    function inputIdentitasPasien($data){
        $this->db->insert('pasien' ,$data);
        return $this->db->affected_rows();
    }

    //----------------- FUNGSI UNTUK PUSAT ------------------------------
    function getDataManajemenPasien(){
        $query = $this->db->query(
        "SELECT 
            sum(pasien.jenis_kelamin like 'pria') as total_odgj_pria,
            sum(pasien.jenis_kelamin like 'wanita') as total_odgj_wanita,
            sum(pasien.nama like '%%') as total_odgj_terdaftar,
            sum(pasien.status_pengobatan like 1) as total_aktif_pengobatan,
            sum(pasien.status_pengobatan like 0) as total_pasif_pengobatan,
            sum(pasien.status_pasien like 0) as total_kematian_pasien
        FROM pasien"
        );
        return $query;
    }
    
    function getDaftarPasien(){
        $query = $this->db->get('pasien');
        return $query;
    }
}