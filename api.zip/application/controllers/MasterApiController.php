<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class MasterApiController extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        date_default_timezone_set("Asia/Jakarta"); 
        $this->dateToday = date("Y-m-d H:i:s");
        $this->timeToday = date("h:i:s");
        $this->load->model("MasterApiModel");
    }

    function showDaftarKelas_get(){
        $result = $this->MasterApiModel->getViewSemuaKelas()->result();
        $this->response(array('status' => 200,'data' => $result));
    }
}