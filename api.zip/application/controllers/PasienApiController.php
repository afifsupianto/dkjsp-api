<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class PasienApiController extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        date_default_timezone_set("Asia/Jakarta"); 
        $this->dateToday = date("Y-m-d H:i:s");
        $this->timeToday = date("h:i:s");
        $this->load->model("PasienApiModel");
    }

    //----------------- FUNGSI UNTUK PUSKESMAS ------------------------------
    function masukkanFormPasien_post() {
        $nama = $this->input->post('nama');
        $puskesmas = $this->input->post('puskesmas');
        $alamat = $this->input->post('alamat');
        $rt = $this->input->post('rt');
        $rw = $this->input->post('rw');
        $desa = $this->input->post('desa');
        $kec = $this->input->post('kec');
        $kota = $this->input->post('kota');
        $alamat_lengkap = implode(', ', array($alamat, 'RT : '.$rt, 'RW : '.$rw, 'desa '.$desa, 'kec. '.$kec,$kota));
        $tanggal_lahir = $this->input->post('tanggal_lahir');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $status_jkn = $this->input->post('status_jkn');
        $status_pengobatan = $this->input->post('status_pengobatan');
        $status_pasien = $this->input->post('status_pasien');
        $data = array(
            'nama' => $nama,
            'puskesmas' => $puskesmas,
            'alamat' => $alamat_lengkap,
            'tanggal_lahir' => $tanggal_lahir,
            'jenis_kelamin' => $jenis_kelamin,
            'status_jkn' => $status_jkn,
            'status_pengobatan' => $status_pengobatan,
            'status_pasien' => $status_pasien,
            'created_at' => $this->dateToday,
            'updated_at' => $this->dateToday
        );
        $message = array();
        if(!$data['nama']){
            $message['nama'] = "nama";
        }if(!$data['puskesmas']){
            $message['puskesmas'] = "puskesmas";
        }if(!$data['alamat']){
            $message['alamat'] = "alamat";
        }if(!$data['tanggal_lahir']){
            $message['tanggal_lahir'] = "tanggal lahir";
        }if(!$data['jenis_kelamin']){
            $message['jenis_kelamin'] = "jenis kelamin";
        }if(!$data['nama'] || !$data['puskesmas'] || !$data['alamat'] || !$data['tanggal_lahir'] || !$data['jenis_kelamin']){
            $message_form = "data ".implode(', ', $message)." tidak ditemukan";
            $this->response(array('status' => 200,'message' => $message_form));
        }else{
            $insert = $this->PasienApiModel->inputIdentitasPasien($data);
            if($insert > 0){
                $this->response(array('status' => 200,'message' => "Success, data berhasil diinputkan!"));
            }
            else{
                $this->response(array('status' => 200,'message' => "Failed, data gagal diinputkan!"));
            }
        }
    }

    //----------------- FUNGSI UNTUK PUSAT ------------------------------

    function showDaftarpasien_get(){
        $data_manajemen = $this->PasienApiModel->getDataManajemenPasien()->result();
        $result = $this->PasienApiModel->getDaftarPasien()->result();
        $this->response(array('status' => 200, 'data_manajemen' => $data_manajemen,'data' => $result));
    }

}